import os

os.environ["MAVLINK20"] = "1"
